# 🚀 Fully Automated Stock Screener Setup Guide (GitHub Actions)

This guide walks you through setting up your daily stock screener using GitHub Actions. It is **completely free**, requires **no software installation** on your computer, and runs automatically in the cloud every day at 9:00 AM Singapore time.

---

## 🛠️ Step 1: Create a GitHub Repository

1. Go to [github.com](https://github.com/) and log in with your `evelynsohyl` account.
2. Click the **`+`** icon in the top right corner and select **New repository**.
3. Set the **Repository name** to `daily-stock-screener`.
4. Choose **Private** (so no one else can see your code).
5. Click **Create repository**.

---

## 🔒 Step 2: Add Your Gmail App Password as a Secret

We do not put passwords directly in code. GitHub provides a secure vault for passwords called "Secrets".

1. In your new repository, click the **Settings** tab (the gear icon ⚙️ near the top right).
2. On the left sidebar, scroll down to **Secrets and variables** and click **Actions**.
3. Click the green **New repository secret** button.
4. Set the **Name** to: `GMAIL_APP_PASSWORD`
5. Set the **Secret** to: `sjef izzp kvbk htay` (your 16-character Gmail App Password).
6. Click **Add secret**.

---

## 📝 Step 3: Upload the Screener Script

1. Go back to your repository's main page by clicking its name (`daily-stock-screener`) at the top left.
2. Click the **uploading an existing file** link (it's small text in the middle of the screen).
3. Upload the `screener.py` file provided by Manus.
4. Click the green **Commit changes** button.

---

## ⏱️ Step 4: Set Up the Automation Schedule

Now we tell GitHub to run the script every day at 9 AM Singapore time.

1. On your repository's main page, click **Add file** → **Create new file**.
2. In the "Name your file..." box, type exactly this:
   `.github/workflows/daily_screener.yml`
   *(Notice the slashes — this creates folders automatically)*
3. Paste the contents of the `daily_screener.yml` file provided by Manus into the large text box.
4. Click **Commit changes** (top right), then **Commit changes** again.

---

## ▶️ Step 5: Test Run It Manually

Let's trigger it right now to make sure everything works!

1. Click the **Actions** tab at the top of your repository.
2. You will see a prompt saying "I understand my workflows, go ahead and enable them" — click the green button to accept.
3. On the left sidebar, click **Daily Stock Screener**.
4. On the right side, click the **Run workflow** dropdown button, then click the green **Run workflow** button inside it.
5. Wait about 10 seconds, then refresh the page. You will see a yellow spinning circle indicating the script is running.
6. Click on it to watch the live progress!

Once it finishes (turns green), check your `evelynsohyl@gmail.com` inbox for the stock report!

---

### 📅 What Happens Next?
You don't need to do anything else. From now on, GitHub will automatically wake up at **9:00 AM Singapore time every weekday (Monday–Friday)**, run the script, and email you the results. You can close the browser and turn off your computer.
